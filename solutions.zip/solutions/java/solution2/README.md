This solution contains code for Part 1 and Part 2 of the challenge.
